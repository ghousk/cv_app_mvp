package com.innovativequest.cv_app_mvp.screens.itemdetail.mvp

import com.innovativequest.cv_app_mvp.app.networkservices.DataService
import com.innovativequest.cv_app_mvp.models.ItemDataResponse
import com.innovativequest.cv_app_mvp.models.ItemDetailFirst
import io.reactivex.Observable
import kotlin.collections.ArrayList

/**
 * Created by Ghous on 17/06/2019.
 */
class ItemDetailModel(private val mDataService: DataService) {

    fun getItemDetailFirst() : Observable<ArrayList<ItemDetailFirst>> {
        return mDataService.itemDetailFirst
    }

//    fun getItemDetailSecond() : Observable<ArrayList<ItemDetailSecond>>{
//        return mDataService.itemDetailSecond
//    }

    fun getUpdatedDataItem(dataItem: ItemDataResponse, itemDetailFirstList: List<ItemDetailFirst>) : ItemDetailFirst? {
//        var filteredItem = itemDetailFirstList.first { searchResult -> searchResult.dbn == dataItem.dbn }

        for(itemDetailFirst in itemDetailFirstList){
            if(itemDetailFirst.dbn.equals(dataItem.dbn)){
                return itemDetailFirst
            }
        }
        return null
    }
}



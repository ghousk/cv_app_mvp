package com.innovativequest.cv_app_mvp.screens.home.dagger

import java.lang.annotation.Retention
import java.lang.annotation.RetentionPolicy

import javax.inject.Scope

/**
 * Created by Ghous on 17/06/2019.
 */
@Scope
@Retention(RetentionPolicy.CLASS)
annotation class HomeScreenScope

package com.innovativequest.cv_app_mvp.screens.itemdetail.mvp

import android.util.Log
import com.innovativequest.cv_app_mvp.app.utils.PreferencesManager
import com.innovativequest.cv_app_mvp.models.ItemDataResponse
import com.innovativequest.cv_app_mvp.screens.itemdetail.ItemDetailActivity
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.android.schedulers.AndroidSchedulers


/**
 * Created by Ghous on 17/06/2019.
 */
class ItemDetailPresenter (private val activityItem: ItemDetailActivity, private val itemDetailView: ItemDetailView, private  val itemDetailModel: ItemDetailModel,
                           private val preferencesManager: PreferencesManager
) {

    private val compositeDisposable = CompositeDisposable()
    private lateinit var mDataItem: ItemDataResponse

    fun onCreate(itemItem: ItemDataResponse) {

        compositeDisposable.addAll(
                subscribeToBackButton(),
                getData())
        mDataItem = itemItem
    }

    private fun subscribeToBackButton(): Disposable {
        return itemDetailView.toolbarStartBtnObs().subscribe {
            activityItem.onBackPressed()
        }
    }

    private fun getData() : Disposable {

        return itemDetailModel.getItemDetailFirst()
                .subscribeOn(AndroidSchedulers.mainThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe( {
                    itemDetailView.setItem(mDataItem, itemDetailModel.getUpdatedDataItem(mDataItem, it))
                },{ Log.d(javaClass.name, it.message)})

        }

    fun onDestroy() {
        compositeDisposable.clear()
    }

}